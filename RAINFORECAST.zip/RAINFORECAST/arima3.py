import pandas as pd
from statsmodels.tsa.stattools import adfuller
from pmdarima import auto_arima
from statsmodels.tsa.arima.model import ARIMA
from sklearn.metrics import mean_squared_error
from math import sqrt
import numpy as np  
import mysql.connector
import time

# Define your MySQL database connection parameters
db_config = {
    'user': 'root',
    'password': '',
    'host': 'localhost',
    'database': 'rainforecast'
}

def adf_test(dataset):
    dftest = adfuller(dataset, autolag='AIC')
    print("1. ADF:", dftest[0])
    print("2. P-Value:", dftest[1])
    print("3. Num Of Lags:", dftest[2])
    print("4. Num Of Observations Used For ADF Regression:", dftest[3])
    print("5. Critical Values:")
    for key, val in dftest[4].items():
        print("\t", key, ":", val)
def create_arima_model(train_data):
    train_data = np.maximum(train_data, 0)  # Ensure non-negativity of training data
    # Handle zero values by adding a small constant
    train_data += 1e-6  # Adding a small constant to avoid zero values
    
    # Try adjusting seasonal differencing parameters
    try:
        stepwise_fit = auto_arima(train_data, trace=True, suppress_warnings=True, seasonal=True, m=4)
    except ValueError as e:
        print("Error occurred in auto_arima:", e)
        # Try disabling seasonal differencing
        print("Trying without seasonal differencing...")
        stepwise_fit = auto_arima(train_data, trace=True, suppress_warnings=True, seasonal=False)
    
    model = ARIMA(train_data, order=stepwise_fit.order)
    model_fit = model.fit()  # Fit the model
    return model_fit



def forecast_data(model_fit, steps, alpha=0.05):
    forecast = model_fit.forecast(steps=steps, alpha=alpha)  # Set confidence level here
    return forecast

def calculate_rmse(predictions, actual):
    rmse = sqrt(mean_squared_error(predictions, actual))
    return rmse

def forecast_and_insert_data():
    # Establish connection to MySQL database
    cnx = mysql.connector.connect(**db_config)
    
    while True:
        # Read data from MySQL into a pandas DataFrame
        query = "SELECT * FROM rainfall_data"
        df = pd.read_sql(query, cnx, index_col='rain_date', parse_dates=True)

        # Drop rows with missing values
        df = df.dropna()

        # Ensure index is of DatetimeIndex type and set frequency to daily
        df.index = pd.to_datetime(df.index)
        # Check for duplicate index values
        if df.index.duplicated().any():
            df = df[~df.index.duplicated()]  # Remove rows with duplicate index values
        df = df.asfreq('D')

        print('Shape of data', df.shape)
        df.head()

        # Handle negative values in actual rainfall data
        df['RAINFALL'] = np.maximum(df['RAINFALL'], 0)  # Ensure non-negativity of actual data

        # Handle zero values by adding a small constant
        df['RAINFALL'] += 1e-6  # Adding a small constant to avoid zero values

        # Annual Forecast
        annual_df = df.resample('A').sum()
        annual_train = annual_df.iloc[:-1]  # Use all but last year for training
        annual_test = annual_df.iloc[-1:]   # Use last year for testing
        annual_model_fit = create_arima_model(annual_train['RAINFALL'])
        annual_forecast = forecast_data(annual_model_fit, len(annual_test))
        annual_rmse = calculate_rmse(annual_forecast, annual_test['RAINFALL'])
        # Fetch the sum of rainfall data for the latest week
        query_total_rain = "SELECT SUM(RAINFALL) AS total_sum FROM rainfall_data WHERE rain_date BETWEEN DATE_SUB(CURDATE(), INTERVAL 1 YEAR) AND CURDATE();"
        cursor = cnx.cursor()
        cursor.execute(query_total_rain)
        total_sum = cursor.fetchone()[0]
        print("total sum is:", total_sum)
        cursor.close()
    
        # Insert forecasted data and RMSE into MySQL table
        cursor = cnx.cursor()
        insert_query = "INSERT INTO rainfall_annual (forecast_date, forecast_annual, total_sum, rmse) VALUES (%s, %s, %s, %s)"

        forecast_date = annual_test.index[-1]
        forecast_data_to_insert = (
            forecast_date,
            annual_forecast[0] if annual_forecast.ndim == 1 else annual_forecast[0][0],
            total_sum,  # corrected variable name here
            annual_rmse  # Store the weekly RMSE
        )
        cursor.execute(insert_query, forecast_data_to_insert)

        # Commit the changes
        cnx.commit()

        # Close the cursor
        cursor.close()

        print("Forecasting process done.")  # Add this line

        # Example condition to break out of the loop
        if some_condition:
            break

        # Wait for 24 hours before next forecast
        #time.sleep(86400)

if __name__ == "__main__":
    forecast_and_insert_data()
