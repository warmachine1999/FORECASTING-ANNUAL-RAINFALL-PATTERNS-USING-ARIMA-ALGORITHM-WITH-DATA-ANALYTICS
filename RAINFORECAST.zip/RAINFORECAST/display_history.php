<!DOCTYPE html>
<html lang="en-us">
<head>	
	<meta charset="utf-8">
	</head>
<body style="background-color:#100c08;">

<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">

<?php
$conn = mysqli_connect("localhost","root","","rainforecast");
$sql = "SELECT rain_date, RAINFALL from rainfall_data order by rain_date desc limit 30;";
$result = $conn->query($sql);

echo '<div class="table" style="width:50%;height:10%;">';
echo '<table class="table2">';
echo '<form action="#" method="GET">';
echo '<label for="search">Select month: </label>';
echo '<br>';
echo '<input type="month" id="search" name="search" min="2020-01" max="2023-12" style="width:20%;height:10%; "'; if(isset($_GET["search"])){echo $_GET["search"];} echo 'class="form-control" required	>'; 
echo '<br>';  
echo '<button type="submit" class="btn btn-primary" style="width:30% height:10%; padding: 10px;">Search</button>';
echo '</form>';

echo '<thead>';
echo '<tr>';
echo '<th scope="col">Date</th>';
echo '<th scope="col">Rainfall</th>';
echo '';
echo '</tr>';
echo '</thead>';
echo '<tbody>';
echo '<tr>';


// TD DISPLAY
try{

	if(!isset($_GET['search'])){

	if($result->num_rows > 0){
	while($row = $result-> fetch_assoc()){
		echo "<tr>";
			echo "<td>";
				$date = $row['rain_date'];
				echo date('M d, Y', strtotime($date));
			echo "</td>";
			
			echo "<td>";
				 
				echo $row['RAINFALL'];
			echo "</td>";
		echo "</tr>";
	}
}
}

if(isset($_GET['search'])){
	$filtervalues = $_GET['search'];
	$sql = "SELECT rain_date, RAINFALL FROM rainfall_data WHERE CONCAT(rain_date) LIKE '%".$filtervalues."%' ";
	$result = $conn->query($sql);
	
if($result->num_rows > 0){
	while($row = $result-> fetch_assoc()){
		echo "<tr>";
			echo "<td>";
				$date = $row['rain_date'];
				echo date('M d, Y', strtotime($date));
			echo "</td>";
			
			echo "<td>";
				
				echo $row['RAINFALL'];
			echo "</td>";
		echo "</tr>";
	}
}

else{
	echo "<script> alert('No Record Found') </script>";
}
}
	// END OF WHILE

}
catch (PDOException $e){
}


// END OF TD DISPLAY


echo '';
echo '';
echo '</tr>';
echo '';
echo '</tbody>';
echo '</table>';
echo '</div>';

?>
</body>
</html>