<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rainfall Data</title>
</head>
<body>

<div class="table" style="width:50%;">
<table class="table text-start align-middle table-bordered table-hover mb-0">
        <thead>
            <tr>
                <th scope="col" style="font-size:15px;">Sum of Rainfall Data</th>
                <th scope="col"style="font-size:15px;">Forecasted Rainfall Data</th>
				<th scope="col" style="font-size:15px;">Percentage Error</th>
                <th scope="col"style="font-size:15px;">Accuracy Level</th>
            </tr>
        </thead>
        <tbody>

<?php
try {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "rainforecast";

    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch latest recorded rainfall data
    $query_latest_recorded = "SELECT total_sum FROM rainfall_annual ORDER BY forecast_date DESC LIMIT 1;";
    ;
    $stmt_latest_recorded = $conn->query($query_latest_recorded);
    $latest_recorded = $stmt_latest_recorded->fetch(PDO::FETCH_ASSOC);

    // Fetch latest forecasted rainfall data
    $query_latest_forecast = "SELECT forecast_annual from rainfall_annual";
    $stmt_latest_forecast = $conn->query($query_latest_forecast);
    $latest_forecast = $stmt_latest_forecast->fetch(PDO::FETCH_ASSOC);

    // Calculate accuracy level
   $actual = $latest_recorded['total_sum'];
    $predicted = $latest_forecast['forecast_annual'];
	$a = $actual - $predicted;
	$b = $a / $actual;
	$c = abs($b) * 100;
	$d = $c - 100;
    

    // Display data in table row
    echo "<tr>";
    echo "<td style='font-size:15px;'>" . $latest_recorded['total_sum'] . "</td>";
    echo "<td style='font-size:15px;'>" . $latest_forecast['forecast_annual'] . "</td>";
	echo "<td style='font-size:15px;'>" . ($c < 0 ? '-' : '') . number_format(abs($c), 2) . "%</td>";
    echo "<td style='font-size:15px;'> " . abs(number_format($d, 2)); echo "%";"</td>";
    echo "</tr>";;
    

} catch (PDOException $e) {
    // Handle exceptions
    echo "Error: " . $e->getMessage();
}


?>
        </tbody>
       
    </table>
    
</div>

</body>
</html>
