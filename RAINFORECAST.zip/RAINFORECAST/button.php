<!DOCTYPE html>
<html>
<head>
    <title>Execute Python Script</title>
    <style>
        #loading {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
            text-align: center;
        }
        #loading img {
            width: 50px;
            height: 50px;
        }
    </style>
    <script>
        function showLoading() {
            document.getElementById("loading").style.display = "block";
        }
    </script>
</head>
<body>
    <h2>Click the button to execute the Python script</h2>
    <form method="post" onsubmit="showLoading()">
        <input type="submit" name="execute_python" value="Execute Python Script">
    </form>

    <div id="loading">
        <svg width="50" height="50" viewBox="0 0 38 38" xmlns="http://www.w3.org/2000/svg" stroke="#000">
            <g fill="none" fill-rule="evenodd">
                <g transform="translate(1 1)" stroke-width="2">
                    <circle stroke-opacity=".5" cx="18" cy="18" r="18"/>
                    <path d="M36 18c0-9.94-8.06-18-18-18">
                        <animateTransform attributeName="transform" type="rotate" from="0 18 18" to="360 18 18" dur="1s" repeatCount="indefinite"/>
                    </path>
                </g>
            </g>
        </svg>
        <p>Loading...</p>
    </div>

    <?php
    if (isset($_POST['execute_python'])) {
        // Execute the Python script
        $output = shell_exec('python arima.py');
        
        // Check if the Python script execution is successful
        if ($output !== null) {
            echo "<p>Python script executed successfully!</p>";
        } else {
            echo "<p>Failed to execute Python script.</p>";
        }
    }
    ?>
</body>
</html>
