<?php
$conn=new mysqli("localhost","root","","oil");

if(!$conn){
	echo "Connection Failed";
}
?> 