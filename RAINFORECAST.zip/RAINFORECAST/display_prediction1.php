<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

<?php
echo '<div class="table-responsive">';
echo '<div class="table" style="width:70%;height:40%; font-size:12px;">';
echo '<table class="table1">';

echo '<thead>';
echo '<th colspan=6 style="font-family: Quicksand; text-align: center; font-size: 36px; border-style: none; background-color: #191C24;">Data Comparison</th>';
echo '</thead>';

echo '<thead>';
echo '<tr >';
echo '<th scope="col">Latest Recorded Date</th>';
echo '<th scope="col">Latest Recorded Price</th>';
echo '<th scope="col">Forecasted Price</th>';
echo '<th scope="col">Percentage Error</th>';
echo '<th scope="col">Accuracy level</th>';
echo '<th scope="col">Probability</th>';
echo '';
echo '</tr>';
echo '</thead>';
echo '<tbody>';



// TD DISPLAY

try {

include ('conn.php');

$query = "select PROBABILITY,date_time,PREDICTED_PRICE,  date_sub(DATE_TIME, INTERVAL 7 day) as prev_date, lag(PREDICTED_PRICE, 1) over (order by ID) as prevprice1,lag(PROBABILITY, 1) over (order by ID) as prevprob from prediction where gastype = 2 order by ID desc limit 1";
$stmt = $conn->prepare($query);
$stmt->execute();

$arr = [];
$arr2 = [];

while ($r = $stmt->fetch()) {
array_push($arr, $r['prevprice1']);
array_push($arr2, $r['prevprob']);
}


$query = "select date_time,price,  date_sub(DATE_TIME, INTERVAL 7 day) as prev_date, lag(price, 1) over (order by date_time) as prevprice from dataset where gastype = 2 order by ID desc limit 1;";
$stmt = $conn->prepare($query);
$stmt->execute();



$iterator = 0;

$reset = 1;
while ($r = $stmt->fetch()) {
	
	
	echo "<tr>";	
	
	echo "<td>"; // actual date
	$cdate = $r['date_time'];
	echo date('M d, Y', strtotime($cdate));
	echo "</td>";
	
	echo "<td>";
	echo "₱";
	echo ($r['price']); // actual data
	echo "</td>";
	
	echo "<td>";
	echo "₱";
	echo ($arr[$iterator]); //pred data
	echo "</td>";
	
	echo "<td>";
	$actual = $r['price'];
	$predicted = $arr[$iterator];
	
	$a = $actual - $predicted;
	$b = $a / $actual;
	$c = abs($b) * 100;
	
	echo abs(number_format($c, 2)); echo "%";	//percentage error
	
	echo "</td>";
	
	echo "<td>";
	$d = $c - 100;
	echo abs(number_format($d, 2)); echo "%"; //accuracy level
	echo "</td>";
	echo "<td>";
	$prob = $arr2[$iterator];
	
	 echo $prob; echo"%";
	echo "</td>";
	
	
	echo "</tr>";
	
	




$reset = $reset + 1;
$iterator = $iterator + 1;
}

	
}

catch (PDOException $e) {
	
}

// END OF TD DISPLAY


echo '';
echo '';

echo '';
echo '</tbody>';
echo '</tbody>';
echo '</table>';
echo '</div>';
echo '</div>';

echo "<h4 style='color: white;'> Result: </h5>";

$percentage = $c;
$error = 5;
$error1 = 25;
if($percentage < $error){
	echo "<h3 style='color:green;'>HIGHLY ACCEPTABLE </h3>";
}
else if($percentage >= $error && $percentage < $error1){
	echo "<h3 style='color:yellow;'> ACCEPTABLE </h3>";
}
else{
	echo "<h3 style='color:red;'> NOT ACCEPTABLE </h3>";
}
?>