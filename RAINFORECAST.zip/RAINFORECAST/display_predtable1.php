<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

<?php

echo '<div class="table-responsive">';
echo '<div class="table" style="width:70%;height:40%;">';
echo '<table class="table text-start align-middle table-bordered table-hover mb-0">';

echo '<thead>';
echo '<tr>';
echo '<th scope="col">Latest Recorded Date</th>';
echo '<th scope="col">Latest Recorded Price</th>';
echo '<th scope="col">Forecasted Price Next Week</th>';
echo '<th scope="col">Probability</th>';
echo '';
echo '</tr>';
echo '</thead>';
echo '<tbody>';
echo "<br>";



// TD DISPLAY

try {


include ('conn.php');

$query = "select PROBABILITY,date_time,PREDICTED_PRICE,  date_sub(DATE_TIME, INTERVAL 7 day) as prev_date, lag(PREDICTED_PRICE, 1) over (order by ID) as prevprice from prediction where gastype = 1 order by ID desc limit 1";
$stmt = $conn->prepare($query);
$stmt->execute();

$arr = [];
$arr2 = [];

while ($r = $stmt->fetch()) {
array_push($arr, $r['PREDICTED_PRICE']);
array_push($arr2, $r['PROBABILITY']);
}


$query = "select date_time,price  from dataset where gastype = 1 order by ID desc limit 1;";
$stmt = $conn->prepare($query);
$stmt->execute();



$iterator = 0;

$reset = 1;
while ($r = $stmt->fetch()) {
	echo "<tr>";
	echo "<td>";
	$cdate = $r['date_time'];
	echo date('M d, Y', strtotime($cdate));
	echo "</td>";
	

	echo "<td>"; 
	echo "₱"; 
	echo ($r['price']); //latest data
	echo "</td>";

	echo "<td>";
	echo "₱";
	echo ($arr[$iterator]); //pred data
	echo "</td>";
	
	
	echo "<td>";
	$prob = $arr2[$iterator];
	
	 echo $prob; echo"%";
	echo "</td>";
	
	echo "</tr>";
	
	
$reset = $reset + 1;
$iterator = $iterator + 1;
}

	
}

catch (PDOException $e) {
	
}

// END OF TD DISPLAY


echo '';
echo '';

echo '';
echo '</tbody>';
echo '</tbody>';
echo '</table>';
echo '</table>';
echo '</div>';





?>