<style>
.range {
	width:20em;
	height: 8px;
	-webkit-appearance: none;
	background: #111;
	outline: none;
	border-radius: 15px;
	overflow: hidden;
	box-shadow: inset 0 0 5px rgba(0,0,0,1);
}
.range::-webkit-slider-thumb{
	-webkit-appearance: none;
	width: 15px;
	height: 15px;
	border-radius: 50%;
	background: #00fd0a;
	border: 4px solid #33;
	box-shadow: -407px 0 0 400px #00fd0a;
}
</style>
<?php
try {


include ('conn.php');

$aray = [];
	$min = 0;
	$max = 0;
	
	$query = "select lag(price, 1) over (order by date_time) as pric from dataset where gastype=2 order by DATE_TIME desc limit 4";
	$stmt = $conn->prepare($query);
	$stmt->execute();
	
	while ($r = $stmt->fetch()) {
		array_push($aray, $r['pric']);
	}
	
	#foreach($aray as $ar){
	#	echo $ar . "<br>";
	#}
	
	$min = min($aray);
	$max = max($aray);
	
	$query = "select price from dataset where gastype=2 order by DATE_TIME desc limit 1";
	$stmt = $conn->prepare($query);
	$stmt->execute();
	
	while ($r = $stmt->fetch()) {
		$price = $r['price'];
	}
	
	echo "
<div style='width: 20em; height:30em;'>
<input disabled class='range' type='range' name=''  min='$min' max='$max' value='$price'>
<h6>
<div style='color: white;'><div style='width: 10%; float: left;'>$min</div> <div style='margin-left: 34%; float: left;'>Range</div> <div style='width: 10%; float: right;'>$max</div>
</div></div></h6>";
array_splice($aray, 0,count($aray));
 }
catch (PDOException $e) {
	
}

?>
<script>
var slider = document.getElementById("myRange");
var output = document.getElementById("demo");
output.innerHTML = slider.value;

slider.oninput = function() {
  output.innerHTML = this.value;
}
</script>