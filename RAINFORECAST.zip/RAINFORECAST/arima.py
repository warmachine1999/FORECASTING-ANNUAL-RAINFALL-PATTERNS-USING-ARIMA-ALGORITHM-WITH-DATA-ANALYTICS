import pandas as pd
from statsmodels.tsa.stattools import adfuller
from pmdarima import auto_arima
from statsmodels.tsa.arima.model import ARIMA
from sklearn.metrics import mean_squared_error
from math import sqrt
import numpy as np  
import mysql.connector
import time

# Define your MySQL database connection parameters
db_config = {
    'user': 'root',
    'password': '',
    'host': 'localhost',
    'database': 'rainforecast'
}

def adf_test(dataset):
    dftest = adfuller(dataset, autolag='AIC')
    print("1. ADF:", dftest[0])
    print("2. P-Value:", dftest[1])
    print("3. Num Of Lags:", dftest[2])
    print("4. Num Of Observations Used For ADF Regression:", dftest[3])
    print("5. Critical Values:")
    for key, val in dftest[4].items():
        print("\t", key, ":", val)

def create_arima_model(train_data):
    train_data = np.maximum(train_data, 0)  # Ensure non-negativity of training data
    # Handle zero values by adding a small constant
    train_data += 1e-6  # Adding a small constant to avoid zero values
    stepwise_fit = auto_arima(train_data, trace=True, suppress_warnings=True, seasonal=True, m=1)
    model = ARIMA(train_data, order=stepwise_fit.order)
    model_fit = model.fit()  # Fit the model
    return model_fit

def forecast_data(model_fit, steps, alpha=0.05):
    forecast = model_fit.forecast(steps=steps, alpha=alpha)  # Set confidence level here
    return forecast


def calculate_rmse(predictions, actual):
    rmse = sqrt(mean_squared_error(predictions, actual))
    return rmse

def forecast_and_insert_data():
    # Establish connection to MySQL database
    cnx = mysql.connector.connect(**db_config)
    
    while True:
        # Read data from MySQL into a pandas DataFrame
        query = "SELECT * FROM rainfall_data"
        df = pd.read_sql(query, cnx, index_col='rain_date', parse_dates=True)

        # Ensure index is of DatetimeIndex type
        df.index = pd.to_datetime(df.index)  # Remove the 'freq' argument

        # Drop rows with missing values
        df = df.dropna()

        # Handle negative values in actual rainfall data
        df['RAINFALL'] = np.maximum(df['RAINFALL'], 0)  # Ensure non-negativity of actual data

        # Handle zero values by adding a small constant
        df['RAINFALL'] += 1e-6  # Adding a small constant to avoid zero values

        # Daily Forecast
        daily_train = df.iloc[:-365]  # Use data up to last year for training
        daily_test = df.iloc[-365:]   # Use data from last year for testing
        daily_model_fit = create_arima_model(daily_train['RAINFALL'])
        daily_forecast = forecast_data(daily_model_fit, len(daily_test))
        daily_rmse = calculate_rmse(daily_forecast, daily_test['RAINFALL'])
        print("Daily RMSE:", daily_rmse)

    
        # Insert forecasted data and RMSE into MySQL table
        cursor = cnx.cursor()
        insert_query = "INSERT INTO rainfall_forecast (forecast_date, forecast_data,  rmse) VALUES (%s, %s, %s)"

        forecast_date = daily_test.index[-1]
        forecast_data_to_insert = (
            forecast_date,
            daily_forecast[0] if daily_forecast.ndim == 1 else daily_forecast[0][0],
            daily_rmse  # Assuming you want to store the daily RMSE; modify as needed
        )
        cursor.execute(insert_query, forecast_data_to_insert)

        # Commit the changes
        cnx.commit()

        # Close the cursor
        cursor.close()

        print("Forecasting process done.")  # Add this line

        # Example condition to break out of the loop
        if some_condition:
            break

        # Wait for 24 hours before next forecast
        #time.sleep(86400)

if __name__ == "__main__":
    forecast_and_insert_data()
