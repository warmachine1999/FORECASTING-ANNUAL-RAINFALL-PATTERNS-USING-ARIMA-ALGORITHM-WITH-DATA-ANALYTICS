<!DOCTYPE html>
<html lang="en-us">
<head>
    <meta charset="utf-8">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
</head>
<body style="background-color:#100c08;">
<center>
<button onclick="window.print()">Print data</button>
</center>

<?php
$conn = mysqli_connect("localhost","root","","rainforecast");
$sql = "SELECT rain_date, RAINFALL as Actual from rainfall_data";
$result = $conn->query($sql);

echo '<center>';
echo '<div class="table-responsive">';
echo '<div class="table" style="width:70%;height:40%;">';
echo '<table class="table text-start align-middle table-bordered table-hover mb-0">';
echo '<thead>';
echo '<tr>';
echo '<th colspan="3" scope="col"><center>Rainfall Data Analysis History</center></th>';
echo '</tr>';
echo '<tr>';
echo '<th scope="col">Date</th>';
echo '<th scope="col">Actual Rain Data</th>';
echo '</tr>';
echo '</thead>';
echo '<tbody>';

try {
    if (!isset($_GET['search'])) {
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . date('M d, Y', strtotime($row['rain_date'])) . "</td>";
                echo "<td>" . $row['Actual'] . "</td>";
                echo "</tr>";
            }
        }
    } else {
        $filtervalues = $_GET['search'];
        $sql = "SELECT rainfall_data.rain_date, rainfall_data.RAINFALL as Actual, rainfall_forecast.forecast_date, rainfall_forecast.forecast_data as Forecast 
                FROM rainfall_data 
                INNER JOIN rainfall_forecast ON rainfall_data.rain_date = rainfall_forecast.forecast_date 
                WHERE CONCAT(rain_date) LIKE '%".$filtervalues."%'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . date('M d, Y', strtotime($row['rain_date'])) . "</td>";
                echo "<td>" . $row['Actual'] . "</td>";
                echo "<td>" . $row['Forecast'] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<script>alert('No Record Found')</script>";
        }
    }
} catch (PDOException $e) {
    echo "<script>alert('Database error: " . $e->getMessage() . "')</script>";
}

echo '</tbody>';
echo '</table>';
echo '</div>';
echo '</div>';
echo '</center>';

?>


</body>
</html>
