<!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title> RainFoWS </title>
	<link rel="icon" href="img/icon.png"> <!-- logo -->
	<!-- whole publictesting.php css -->
	<link rel="stylesheet" type="text/css" href="publictesting.css">
	
	<!-- Line Chart -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
	<link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />
	<link href="css/bootstrap.min.css" rel="stylesheet">
	
	<!-- Google Fonts -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Open+Sans&family=Roboto" rel="stylesheet">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Satisfy">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Quicksand">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Yantramanav">
<style>
	.row {
  display: flex;
}


.column {
  flex: 30%;
  padding: 5px;
}
</style>	
	
	
</head>
<body style="background-color:#36454F;">

	<div >
	<!-- NAVBAR -->
	<div class="navbar" style="width:100%;">
	<img src="img/RFWS.png" style="width:5%; height:2%;position: left;">

		<ul type=none>
			<li><a href="#aboutus"> About </a></li>
			<li class="dropdown"><a href="#datarecords"> Data Records </a>
				<div class="dropdown-content">
					<a href="print.php" target="_blank"> Print Rainfall Records </a>
				</div>
			</li>
			<li><a href="#datacomp"> Data Comparison </a></li>
			<li><a href="#rainchart"> Rainfall Chart </a></li>
			
		</ul>
	</div>
	</div>
	<!-- END NAVBAR -->

	
	<!--START OF IMAGE CAROUSEL -->
	
	<div class="slider">
		<div class="slides">
			<input type="radio" name="radio-btn" id="radio1">
			<input type="radio" name="radio-btn" id="radio2">
			<input type="radio" name="radio-btn" id="radio3">
		
			<div class="slide first">
				<div class="banner">
					<img src="bg1.png">
					<h3 class="heading1"> YOUR RELIABLE RAINFALL FORECASTING SITE </h3>
				</div>
			</div>
			<div class="slide">
				<div class="banner">
					<img src="bg2.jpg">
					<h3 class="heading2"> PROVIDING FILIPINOS WITH BETTER SOLUTIONS </h3>
				</div>
			</div>
			<div class="slide">
				<div class="banner">
					<img src="bg3.png">
					<h3 class="heading3"> DISCOVER DAILY RAINFALL FORECAST WITH US NOW! </h3>
				</div>
			</div>
			
			<div class="navigation-auto">
				
			</div>
		</div>
		
		
	</div>
	
	<script type="text/javascript">
		var counter = 1;
		setInterval(function(){
			document.getElementById('radio' + counter).checked = true;
			counter++;
			
			if(counter > 3){
				counter = 1;
			}
		}, 10000);
	</script>
	<!-- END IMAGE CAROUSEL -->
                            
	<!-- START OF RAINFALL CHART -->						
							<br>
							<center>
							<div id ="rainchart">
							<?php
								include ('display_prediction.php'); //chart
							?>
							</div>
							</center>
						</div>
					</div>
				</div>
			</div>
		</section>
	<!-- END OF RAINFALL CHART -->
	
	
	<!-- START OF DATA COMPARISON -->
	<center>
	<hr style="width: 75%; color: white;">
	
	<br>
		<hr style="width: 30%; color: white;">
		<br>
		<div id ="datacomp">
		<section>
			<h1 style="color: white;">Data Comparison</h1>
			<br>
			<div class="row" >
			<div class="column">
				<h6 class="mb-0">Daily Forecast</h6>
			<?php
				include ('data_comp.php'); //daily
			?>
  			</div>
			  <div class="column">
			  <h6 class="mb-0">Weekly Forecast</h6>
			<?php
				include ('data_comp1.php'); //weekly
			?>
  			</div>
			</div>
			<div class="row" >
			  <div class="column">
				<h6 class="mb-0">Monthly Forecast</h6> 
			<?php
				include ('data_comp2.php'); //monthly
			?>
  			</div>
			  <div class="column">
			  <h6 class="mb-0">Annual Forecast</h6>
			<?php
				include ('data_comp3.php'); //annual
			?>
  			</div>
			</div>
		</section>
		<br>
		<hr style="width: 30%; color: white;">
	</div>
		</center>
	
	
	
	<!-- END OF DATA COMPARISON -->
	
	
	
	<center>
	<hr style="width: 75%; color: white;">
	</center>
	<br>
	
	
	
	<!-- TEAM -->
	<section>
	<div id="aboutus">
		<center>
		<h1 class="about" style="font-family: Quicksand; font-size: 36px; color: white;"> ABOUT US </h1>
		<br>
		<img src="img/RFW.png" style="width:15%; height:15%;">
		<br>
		<br>
		<div style="width: 50%; display: flex;">
			<p style="font-family: Quicksand; color: white; font-size: 15px;">The project RainFoWS  or Rainfall Forecast Web System, run by BSIT students of Our Lady of Fatima University Quezon City, gives estimated rainfall forecast for the Quezon City region..
			The project team forecasts potential future rainfall data within the specified location and analyzes rainfall data behavior using the annual data provided by PAGASA.</p><br><br>
			<br><br>
		</div>
	<br><br>
	</section>
	
	<br><br>
	
	<section>
	<center>
		<div style="width: 20%; display: flex;">
			<p style="font-family: Quicksand; font-size:14px; color: white;">For suggestions and concerns please reach us out at <br>
			<a href="https://mail.google.com"> rainfows@gmail.com </a> </p>
		</div>
	</center>
	</section>
	<!-- END TEAM -->
	
	<br><br>
	
	<!-- FOOTER -->
	<section>
	<footer>
	<center>
		<div style="width: 100%; background-color: #6c757d">
			<p style="padding: 1px; font-family: Quicksand; color: white; font-weight: bold;"> RainFoWS | Rainfall Forecast Web System </p>
		</div>
	</center>
	</footer>
	</section>
	<!-- END FOOTER -->
	
	
	
	</main>
	

</body>
</html>