<div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-12">
                        <div class="bg-secondary rounded h-100 p-4">
                            <h6 class="mb-4">Kerosene Price Chart</h6>
                            <div class = "zoomIn">
                            <canvas id="line-chart1">
							</canvas></div>

                            
                        </div>
                    </div>

                </div>
            </div>