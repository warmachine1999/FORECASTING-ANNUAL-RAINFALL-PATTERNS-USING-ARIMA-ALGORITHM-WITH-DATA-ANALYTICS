<!DOCTYPE html>
<html lang="en-us">
<head>	
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="../css/gym.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
	<link rel="icon" href="../img/icon.png">
	<title> RainFoWS ADMIN PAGE</title>
		
</head>
<body>
	
	<!-- NAVIGATION BAR -->
	<nav>
	<div class="navbar" id="keep">
		<ul>
			<li><img src="../img/RFWS.png" style="width:100px;height:50px;"></li>
			<li><a href="../dashboard.php">Rainfall Chart </a></li>
			<li><a href="../insert.php">Insert Data</a></li>
			<li><a href="apphistory.php">Rainfall History</a></li>
			<li><a href="../registration/reg.php">Forecast Data</a></li>
			


	</div>
	</nav>
	
	<!--main area-->
	<main id="display-b">
	<br>
	<br>
	<br>
<div class="wrapper">
			<div class="reg_form">
				<div class="title">
					Insert Data
				</div>
				
				<form action="app_conn.php" method="post">
					<div class="form_wrap">
						<div class="input_grp">
							
							
							<div class="input_wrap">
								<label for="rain_date"> Date</label>
								<input type="date" id="rain_date" name="rain_date" value="<?php echo date('Y-m-d'); ?>" required>

							</div>
							
							<div class="input_wrap">
								<label for="RAINFALL"> Insert Rainfall Data </label>
								<input type="text" id="RAINFALL" name="RAINFALL"required>
							</div>
						</div>
						
							
							
							
						<br>
								<input type="submit" id="submit" name="submit" value="submit" class="submit_btn">
							</div>
								
					</div>
				</form>
			</div>
		</div>
		
		
		
		
	
	
	

	</main>
	
	
	<footer>
	
		<div class="foot">
			<center>© 2023. <a href="#">TECHX </a> All rights reserved.</center>
		</div>
	</footer>
	</body>
	<script>
function togglePopup(){
	document.getElementById("popup-1").classList.toggle("active");
}
	</script>
</html>
