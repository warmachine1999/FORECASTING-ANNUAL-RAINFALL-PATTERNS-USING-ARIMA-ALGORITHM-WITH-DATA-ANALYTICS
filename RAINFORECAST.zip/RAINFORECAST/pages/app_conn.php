<!DOCTYPE html>
<html lang="en-us">
<head> 
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="../css/gym.css">
    <title>RAINFALLX ADMIN PAGE</title>
        
</head>
<body class="display-c">
    
<?php
$conn = mysqli_connect('localhost','root','','rainforecast')OR DIE ("Unable to connect to server");

if($conn->connect_error){
    echo "$conn->connect_error";
    die("Connection Failed : ". $conn->connect_error);
}

if(isset($_POST['submit'])){
    $rain_date = $_POST['rain_date'];
    $RAINFALL = $_POST['RAINFALL'];

    // Prepare and bind the SQL query
    $stmt = $conn->prepare("INSERT INTO rainfall_data (rain_date, RAINFALL) VALUES (?, ?)");
    $stmt->bind_param("ss", $rain_date, $RAINFALL);

    // Execute the query
    if($stmt->execute()) {
        echo "<div class='dispC'>
                <p>DATA INSERTED<br>SUCCESSFUL!</p>
                <a href='insert.php'><h6>Insert New Data</h6></a>
            </div>";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>



</body>
</html>
