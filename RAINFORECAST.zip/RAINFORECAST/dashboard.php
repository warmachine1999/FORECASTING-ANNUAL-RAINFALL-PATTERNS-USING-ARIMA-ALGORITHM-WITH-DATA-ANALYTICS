<!DOCTYPE html>
<html lang="en-us">
<head>	
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/gym.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="icon" href="img/icon.png">
	<title> RainFoWS ADMIN PAGE</title>
		
</head>
<body >
	
	<!-- NAVIGATION BAR -->
	<nav>
	<div class="navbar" id="keep">
		<ul>
			<li><img src="img/RFWS.png" style="width:100px;height:50px;"></li>
			<li><a href="../dashboard.php">Rainfall Chart </a></li>
			<li><a href="pages/insert.php">Insert Data</a></li>
			<li><a href="apphistory.php">Rainfall History</a></li>
			<li><a href="../registration/reg.php">Forecast Data</a></li>
			


	</div>
	</nav>
	
	<!--main area-->
	<main id="display-b">
	
	
	<center>
		<br>
		<br>
		<br>
		<br>
		<br>
		
			<?php
				include ('display_prediction.php');

				?>
			<center>
	<hr style="width: 75%; color: black;">
	</center>					
		
	<section>
			<h1 >Data Comparison</h1>
			<br>
			<div class="row" >
			<div class="column">
				<h6 class="mb-0">Daily Forecast</h6>
			<?php
				include ('data_comp.php'); //daily
			?>
  			</div>
			  <br>
			  <div class="column">
			  <h6 class="mb-0">Weekly Forecast</h6>
			<?php
				include ('data_comp1.php'); //weekly
			?>
  			</div>
			</div>
			<br>
			<div class="row" >
			  <div class="column">
				<h6 class="mb-0">Monthly Forecast</h6> 
			<?php
				include ('data_comp2.php'); //monthly
			?>
  			</div>
			  <br>
			  <div class="column">
			  <h6 class="mb-0">Annual Forecast</h6>
			<?php
				include ('data_comp3.php'); //annual
			?>
  			</div>
			</div>
		</section>
		</center>
		<br>
		<br>
	<br>
	<br>
	</main>
	
	<footer>
	
		<div class="foot">
			<center>© 2024. <a href="#">RAINFALLX </a> All rights reserved.</center>
		</div>
	</footer>
	</body>
	<script>
function togglePopup(){
	document.getElementById("popup-1").classList.toggle("active");
}
	</script>
</html>

