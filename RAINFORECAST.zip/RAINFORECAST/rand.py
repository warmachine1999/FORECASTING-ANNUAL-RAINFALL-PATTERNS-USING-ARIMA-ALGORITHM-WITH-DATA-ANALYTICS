import pandas as pd
import mysql.connector

# Define your MySQL database connection parameters
db_config = {
    'user': 'root',
    'password': '',
    'host': 'localhost',
    'database': 'rainforecast'
}

def load_actual_data(start_date, end_date):
    """Load actual data from MySQL database for the specified date range."""
    cnx = mysql.connector.connect(**db_config)
    query = f"SELECT * FROM rainfall_data WHERE rain_date BETWEEN '{start_date}' AND '{end_date}'"
    df = pd.read_sql(query, cnx, index_col='rain_date', parse_dates=['rain_date'])
    cnx.close()
    return df

def find_similar_data(actual_data):
    """Find similar data points for each actual data point."""
    cnx = mysql.connector.connect(**db_config)  # Establish connection inside the function
    similar_data = []
    for index, row in actual_data.iterrows():
        # Assuming 'forecast_data' is fetched from the database
        forecast_data = row['forecast_data']  # Adjust this according to your actual data source
        query = f"SELECT * FROM rainfall_data WHERE rain_date != '{index}' ORDER BY ABS(rainfall - {forecast_data}) LIMIT 1"
        similar_point = pd.read_sql(query, cnx, index_col='rain_date', parse_dates=['rain_date'])
        similar_data.append(similar_point)
    cnx.close()  # Close connection after the loop
    return pd.concat(similar_data)

def insert_data_into_database(data):
    """Insert data into MySQL database."""
    cnx = mysql.connector.connect(**db_config)
    cursor = cnx.cursor()
    insert_query = "INSERT INTO rainfall_forecast (forecast_date, forecast_data) VALUES (%s, %s)"
    for index, row in data.iterrows():
        cursor.execute(insert_query, (index, row['forecast_data']))
    cnx.commit()
    cursor.close()
    cnx.close()

if __name__ == "__main__":
    # Define start and end dates
    start_date = '2020-01-01'
    end_date = '2023-12-31'

    # Load actual data from database
    actual_data = load_actual_data(start_date, end_date)

    # Find similar data points
    similar_data = find_similar_data(actual_data)

    # Insert data into database
    insert_data_into_database(similar_data)

    print("Data inserted successfully!")
