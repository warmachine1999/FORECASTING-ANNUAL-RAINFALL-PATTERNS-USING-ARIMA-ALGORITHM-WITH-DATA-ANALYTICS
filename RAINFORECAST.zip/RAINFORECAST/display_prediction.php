<?php
$username = "root";
$password = "";
$database = "rainforecast";

try{
    $pdo = new PDO ("mysql:host=localhost;database=$database", $username,$password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e){
    die("ERROR: Could not connect. " . $e->getMessage());
}
?>
<!doctype html>
<html lang="en">
    
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Rainfall Data Chart</title>
	<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
      * {
        margin: 0;
        padding: 0;
        font-family: sans-serif;
      }
      .chartMenu {
        width: 100vw;
        height: 40px;
        background: #1A1A1A;
        color: rgba(54, 162, 235, 1);
      }
      .chartMenu p {
        padding: 10px;
        font-size: 20px;
      }
      .chartCard {
        width: 100vw;
        height: calc(100vh - 40px)
        display: flex;
        align-items: center;
        justify-content: center;
      }
      .chartBox {
        width: 80%;
        padding: 20px;
        border-radius: 20px;
        border: solid 3px grey;
        background: white;
      }
    </style>
  </head>
  <body>
    
    <div class="chartCard">
      <div class="chartBox">
        <input type = "date" onchange="startDateFilter(this)" value="2020-01-01" min="2020-01-01" max="2023-11-31">
        <input type = "date" onchange="endDateFilter(this)" value="2023-12-31" min="2020-01-01" max="2023-12-31">
        <canvas id="myChart"></canvas>
      </div>
    </div>
    <?php
   try {
    $sql = "SELECT rain_date, RAINFALL as Actual from rainforecast.rainfall_data;";
   // $sql = "SELECT rainfall_data.rain_date, rainfall_data.RAINFALL as Actual, rainfall_forecast.forecast_date, rainfall_forecast.forecast_data as Forecast
   // FROM rainforecast.rainfall_data
   // INNER JOIN rainforecast.rainfall_forecast
   // ON rainfall_data.rain_date = rainfall_forecast.forecast_date;";
    
    $result = $pdo->query($sql);

    if ($result->rowCount() > 0) { // Added $ before result
        while ($row = $result->fetch()) {
            $rain_dateArray[] = $row["rain_date"];
            $rainfallArray[] = $row["Actual"]; // Corrected "Actuall" to "Actual"
           // $rainfall2Array[] = $row["Forecast"];
        }
        unset($result);
    } else {
        echo "No Result in DB";
    }
} catch (PDOException $e) {
    die("Error: " . $e->getMessage()); // Display actual error message for debugging
}
unset($pdo);


    ?>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/chart.js/dist/chart.umd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns/dist/chartjs-adapter-date-fns.bundle.min.js"></script>
    <script>
const dateArrayJS = <?php echo json_encode($rain_dateArray); ?>;

const dateChartJS = dateArrayJS.map((day, index) => {
    let dayjs = new Date(day);
    console.log(dayjs);
    return dayjs.setHours(0,0,0,0);
});
console.log(dateChartJS);

// setup 
const data = {
  labels: dateChartJS,
  datasets: [
    {
      label: 'Actual Rainfall Data',
      data: <?php echo json_encode($rainfallArray); ?>,
      backgroundColor: [
        'rgba(255, 26, 104, 0.2)',
      ],
      borderColor: [
        'rgba(255, 26, 104, 1)',
      ],
      borderWidth: 1
    }//,
   // {
      //label: 'Forecasted Rainfall Data',
     // data: <//?php echo json_encode($rainfall2Array); ?>,
     // backgroundColor: [
      //  'rgba(0, 0, 255, 0.2)',
     // ],
    //  borderColor: [
    //    'rgba(0, 0, 255, 1)',
    //  ],
     // borderWidth: 1
   // }
  ]
};

// config 
const config = {
  type: 'line',
  data,
  options: {
    scales: {
      x: {
        min: '2020-01-01',
        max: '2023-12-31',
        type: 'time',
        time: {
          unit: 'day'
        }
      },
      y: {
        beginAtZero: true
      }
    }
  }
};

// render init block
const myChart = new Chart(
  document.getElementById('myChart'),
  config
);

function startDateFilter(date){
    const startDate = new Date(date.value);
    console.log(startDate.setHours(0,0,0,0));
    myChart.config.options.scales.x.min = startDate.setHours(0,0,0,0);
    myChart.update();
}

function endDateFilter(date){
    const endDate = new Date(date.value);
    console.log(endDate.setHours(0,0,0,0));
    myChart.config.options.scales.x.max = endDate.setHours(0,0,0,0);
    myChart.update();
}

// Instantly assign Chart.js version
const chartVersion = document.getElementById('chartVersion');
chartVersion.innerText = Chart.version;
</script>


  </body>
</html>