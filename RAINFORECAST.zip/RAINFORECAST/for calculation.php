<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<?php
include ('conn.php');


$query = "SELECT PREDICTED_PRICE from prediction order by DATE_TIME;";
	$stmt = $conn->prepare($query);
	$result = $stmt->execute();

echo '<thead>';
echo '<tr class="text-white">';
echo '<th scope="col">Anticipated Date</th>';
echo '<th scope="col">Anticipated Price</th>';
echo '<th scope="col">Percentage Error</th>';
echo '<th scope="col">Accuracy level</th>';
echo '';
echo '</tr>';
echo '</thead>';
echo '<tbody>';
echo '<tr>';



	echo "<tr>";	
	
	
	echo "<td>";
	echo $r['DATE_TIME'];
	echo "</td>";
	
	echo "<td>";
	echo $r['PREDICTED_PRICE'];
	echo "</td>";
	
	echo "<td>";
	 $ans = $r['PREDICTED_PRICE'] - $r['dataset'];
		$percentage = $ans / $r['dataset'];
		echo $percentage;
	
	echo "</td>";
	
	echo "<td>";
	echo $r['ACCURACY_LEVEL']; //for level of accuracy
	echo "</td>";
echo "</tr>";



// END OF TD DISPLAY


echo '';
echo '';
echo '</tr>';
echo '';
echo '</tbody>';
echo '</table>';
echo '</div>';





?>