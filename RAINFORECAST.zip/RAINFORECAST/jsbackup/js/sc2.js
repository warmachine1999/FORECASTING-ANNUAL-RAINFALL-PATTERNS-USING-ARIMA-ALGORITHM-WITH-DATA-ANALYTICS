

(function ($) {


    



    "use strict";

    // Spinner
    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner();
    
    
    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });


    // Sidebar Toggler
    $('.sidebar-toggler').click(function () {
        $('.sidebar, .content').toggleClass("open");
        return false;
    });


    // Progress Bar
    $('.pg-bar').waypoint(function () {
        $('.progress .progress-bar').each(function () {
            $(this).css("width", $(this).attr("aria-valuenow") + '%');
        });
    }, {offset: '80%'});


    // Calender
    $('#calender').datetimepicker({
        inline: true,
        format: 'L'
    });


    // Testimonials carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        items: 1,
        dots: true,
        loop: true,
        nav : false
    });


    // Chart Global Color
    Chart.defaults.color = "#6C7293";
    Chart.defaults.borderColor = "#000000";
    




    var prc1 = new Array();
    var dt = new Array();
    
    var ajax = new XMLHttpRequest();
    ajax.open("GET", "js/jscrud/get_prediction1.php", true);
    ajax.send();
    
    ajax.onload = function() {
        if (this.readyState == 4 && this.status == 200) {
            var data = JSON.parse(this.responseText);
            //console.log(data);
    
    
    
            var html = "";
            for(var b = 0; b < data.length; b++) {
            prc1.push(parseInt(data[b].PRICE));
            dt.push(String(data[b].DATE_TIME));
            }
            //document.getElementById("data").innerHTML += html;
        }
       
    };


    


    // Single Line Chart
    var x = prc1;
    console.log(typeof x);
    console.log(x);
    var ctx3 = $("#line-chart1").get(0).getContext("2d");
    var myChart3 = new Chart(ctx3, {
        type: "line",

        data: {
            labels: dt,
            datasets: [{
                label: "Kerosene Price",
                fill: false,
                backgroundColor: "rgba(235, 22, 22, .7)",
                data: prc1
            }]
        },
        options: {
            responsive: true
        }
    });

    




    
})(jQuery);

