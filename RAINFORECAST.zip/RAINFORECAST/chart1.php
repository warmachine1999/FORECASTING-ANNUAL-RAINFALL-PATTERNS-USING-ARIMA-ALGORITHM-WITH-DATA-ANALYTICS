<?php include ('db.php'); ?>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  </head>
  <body>
	<form action="#" method="GET">
	<label for="search">Start month:</label>
	<input type="month" id="search" name="search"
       min="2017-01" max="2022-12" <?php if(isset($_GET['search'])){echo $_GET['search']; } ?> class="form-control">
	   
	<button type="submit" class="btn btn-primary">Search</button>
	</form>
	
	
	<script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
        ['Year', 'Price'],
		
       
		
		
		<?php
		# DISPLAYING ALL RECORDS #
        if(!isset($_GET['search']))
        {
			$conn = mysqli_connect("localhost","root","","oil");
            $query = "SELECT * FROM dataset_backup";
			$res = mysqli_query($conn,$query);
            while($data=mysqli_fetch_array($res)){
              $year=$data['DATE_TIME'];
              $sale=$data['PRICE'];
             
           ?>
		   
        ['<?php echo $year;?>',<?php echo $sale;?>],   
        <?php   
            }
		}
		# END DISPLAYING ALL RECORDS #
        ?> 
		
		
		<?php
		# FILTERING RECORDS PER YEAR & MONTH #
        if(isset($_GET['search']))
        {
			$conn = mysqli_connect("localhost","root","","oil");
            $filtervalues = $_GET['search'];
            $query = "SELECT * FROM `dataset_backup` WHERE CONCAT(`DATE_TIME`) LIKE '%".$filtervalues."%'";
			$res = mysqli_query($conn,$query);
            while($data=mysqli_fetch_array($res)){
              $year=$data['DATE_TIME'];
              $sale=$data['PRICE'];
             
           ?>
		   
        ['<?php echo $year;?>',<?php echo $sale;?>],   
        <?php   
            }
		}
		# END FILTERING RECORDS PER YEAR & MONTH #
        ?> 
		
        ]);

        var options = {
          title: 'Oil Price Chart', 
          hAxis: {title: 'Year',  titleTextStyle: {color: '#333'}},
          vAxis: {minValue: 0}
		  
        };

        var chart = new google.visualization.AreaChart(document.getElementById('chart_div'));
        chart.draw(data, options);
      }
    </script>
	
    <div id="chart_div" style="width: 100%; height: 500px;"></div>
	
  </body>
</html>
