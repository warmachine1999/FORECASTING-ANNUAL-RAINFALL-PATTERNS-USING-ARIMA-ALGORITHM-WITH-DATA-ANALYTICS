<!DOCTYPE html>
<html>
<style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
        }
        .background {
            position: relative;
            width: 100%;
            height: 100vh; /* Full viewport height */
            background-image: url('path/to/your/background.jpg');
            background-size: cover;
            background-position: center;
        }
        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover; /* Ensures the overlay image covers the entire background */
        }
    </style>
<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="../css/rnfx.css">
    <title>Login</title>
    
</head>
<body>
<div class="background">
        <img src="../img/bg.jpg" alt="Overlay Image" class="overlay">
    </div>
<?php
    require('db_conn.php');
    session_start();
	$con = mysqli_connect("localhost","root","","rainforecast");
    // When form submitted, check and create user session.
    if (isset($_POST['email'])) {
        $email = stripslashes($_REQUEST['email']);    // removes backslashes
        $email = mysqli_real_escape_string($con, $email);
        $password = stripslashes($_REQUEST['password']);
        $password = mysqli_real_escape_string($con, $password);
        // Check user is exist in the database
        $query    = "SELECT * FROM `accounts` WHERE email='$email'
                     AND password='" . md5($password) . "'";
        $result = mysqli_query($con, $query) or die(mysql_error());
        $rows = mysqli_num_rows($result);
        if ($rows == 1) {
            $_SESSION['email'] = $email;
            // Redirect to user dashboard page
            header("Location: dashboard.php");
        } else {
            echo "<div class='container'>
                  <h3>Incorrect Username/password.</h3><br/>
                  <p class='link'>Click here to <a href='login.php'>Login</a> again.</p>
                  </div>";
        }
    } else {
?>
	<div class="center">
			<div class="container">
				
				<div class="text"> LOGIN </div>
				<form method="POST" action="log_conn.php">
				
				
		
					<div class="data">
						<label for="email"> Email </label>
						<input type="email" id="email" name="email" placeholder="Email" required>
					</div>
					<div class="data">
						<label for="password"> Password </label>
						<input type="password" id="password" name="password" placeholder="Password" required>
					</div>
					<div class="btn">
						<div class="inner"> </div>
						
						<button type="submit"> login </button>
					</div>
					
				
				
				</form>
			</div>
		</div>

<?php
    }
?>
</body>
</html>