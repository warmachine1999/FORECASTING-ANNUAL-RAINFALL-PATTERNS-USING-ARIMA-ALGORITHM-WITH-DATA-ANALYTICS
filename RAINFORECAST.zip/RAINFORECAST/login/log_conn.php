<html>

<head>
    <meta charset="utf-8"/>
	<link rel="stylesheet" type="text/css" href="../css/gym.css">
    <title>Login</title>
    
</head>
<body class="display-c">
<?php
	$email = $_POST['email'];
	$password = $_POST['password'];
	
	$con = new mysqli("localhost","root","","rainforecast");
	if($con->connect_error){
		die("Failed to connect : ".$con->connect_error);
	}
		else{
			$stmt = $con->prepare("select * from accounts where email = ?");
			$stmt->bind_param("s",$email);
			$stmt->execute();
			$stmt_result = $stmt->get_result();
			if($stmt_result->num_rows > 0){
				$data = $stmt_result->fetch_assoc();
				if($data['password'] === $password){
					?>
					
				<div class="dispC">
				<p>
					<?php
						echo" LOGIN <br>
						SUCCESSFUL! ";
					?>
				</p>
				<a href="../dashboard.php">
					<h6>
						<?php echo" Go to Dashboard ";
						$stmt->close();
						?>
						
						
					</h6>
				</a>
			</div>
				
				<?php
				}
			else{?>
		<div class="dispC">
				<p>
					<?php
						echo" <h4>INCORRECT <br>
						EMAIL OR PASSWORD!</h4> ";
					?>
				</p>
				<a href="login.php">
					<h6><?php
						 echo" Go back to Login ";
						$stmt->close();?>
						
						
						
					</h6>
				</a>
			</div><?php
			}}}
		
?>
</body>
</html>