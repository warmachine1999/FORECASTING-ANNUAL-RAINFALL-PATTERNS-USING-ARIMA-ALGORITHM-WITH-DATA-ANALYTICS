<?php
$conn = mysqli_connect("localhost", "root", "", "oil");
$result = mysqli_query($conn, "(select * from dataset where gastype=2 order by date_time desc limit 100) order by date_time asc;");

$data = array();
while ($row = mysqli_fetch_object($result))
{
    array_push($data, $row);
}

echo json_encode($data);
exit();