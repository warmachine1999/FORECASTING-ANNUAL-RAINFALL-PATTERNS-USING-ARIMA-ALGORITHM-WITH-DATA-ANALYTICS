<?php
$conn = mysqli_connect("localhost", "root", "", "rainforecast");
$result = mysqli_query($conn, "(select RAINFALL, rain_date from rainfall_data order by rain_date desc limit 365)order by rain_date asc;");

$data1 = array();
while ($row = mysqli_fetch_object($result))
{
    array_push($data1, $row);
}

echo json_encode($data1);
exit();