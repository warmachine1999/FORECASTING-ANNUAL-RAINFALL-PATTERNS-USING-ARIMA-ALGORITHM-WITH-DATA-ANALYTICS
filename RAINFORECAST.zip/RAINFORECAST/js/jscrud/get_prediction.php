<?php
$conn = mysqli_connect("localhost", "root", "", "rainforecast");
$result = mysqli_query($conn, "(select * from rainfall_forecast desc limit 365) order by forecast_date asc;");

$data = array();
while ($row = mysqli_fetch_object($result))
{
    array_push($data, $row);
}

echo json_encode($data);
exit();