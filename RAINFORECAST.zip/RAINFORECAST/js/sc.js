

(function ($) {


    



    "use strict";

    // Spinner
    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner();
    
    
    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });


    // Sidebar Toggler
    $('.sidebar-toggler').click(function () {
        $('.sidebar, .content').toggleClass("open");
        return false;
    });


    // Progress Bar
    $('.pg-bar').waypoint(function () {
        $('.progress .progress-bar').each(function () {
            $(this).css("width", $(this).attr("aria-valuenow") + '%');
        });
    }, {offset: '80%'});


    // Calender
    $('#calender').datetimepicker({
        inline: true,
        format: 'L'
    });


    // Testimonials carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        items: 1,
        dots: true,
        loop: true,
        nav : false
    });


    // Chart Global Color
    Chart.defaults.color = "#6C7293";
    Chart.defaults.borderColor = "#000000";
    




    var prc = new Array();
	var prc_dies= new Array();
    var dt = new Array();
    
    var ajax = new XMLHttpRequest();
    ajax.open("GET", "js/jscrud/get_dies.php", true); //rainfall data
    ajax.send();
    
    ajax.onload = function() {
        if (this.readyState == 4 && this.status == 200) {
            var data = JSON.parse(this.responseText);
            //console.log(data);
    
    
    
            var html = "";
            for(var a = 0; a < data.length; a++) {
            prc.push(parseInt(data[a].RAINFALL));
            dt.push(String(data[a].rain_date));
            }
            //document.getElementById("data").innerHTML += html;
        }
       
    };
	
	
	var ajax = new XMLHttpRequest();
    ajax.open("GET", "js/jscrud/get_prediction.php", true); //predicted data
    ajax.send();
    
    ajax.onload = function() {
        if (this.readyState == 4 && this.status == 200) {
            var data = JSON.parse(this.responseText);
            //console.log(data);
    
    
    
            var html = "";
            for(var a = 0; a < data.length; a++) {
            prc_dies.push(parseInt(data[a].forecast_data));
            }
            //document.getElementById("data").innerHTML += html;
        }
       
    };


    


    // Single Line Chart
    var x = prc;
    console.log(typeof x);
    console.log(x);

	
	
    var ctx2 = $("#line-chart").get(0).getContext("2d");
    var myChart2 = new Chart(ctx2, {
        type: "line",
        data: {
            labels: dt,
            datasets: [{
                    label: "Actual DATA",
                    data: prc,
                    backgroundColor: "rgba(235, 22, 22, .7)",
                    fill: true
                },
                {
                    label: "Forcasted DATA",
                    data: prc_dies,
                    backgroundColor: "rgba(219, 204, 28, .7)",
                    fill: true
                }
            ]
            },
        options: {
            responsive: true
        }
    });
	
	

    




    
})(jQuery);

