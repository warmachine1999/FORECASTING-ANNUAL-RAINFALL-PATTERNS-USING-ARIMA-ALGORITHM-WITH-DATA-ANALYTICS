<?php


try {

include('conn.php');
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
echo "Post True";




$query = "INSERT INTO `dataset` (`PRICE`, `DATE_TIME`, `GASTYPE`) VALUES (:price, :dt, :gas)";

$stmt = $conn->prepare($query);

echo $query;


$stmt->bindParam(":price",$_POST['price']);
$stmt->bindParam(":dt",$_POST['dt']);
$stmt->bindParam(":gas",$_POST['gastype']);
$stmt->execute();




} // END OF IF
else {

echo "False";


} //END OF ELSE

}
catch (PDOException $e) {

echo $e;
}

?>