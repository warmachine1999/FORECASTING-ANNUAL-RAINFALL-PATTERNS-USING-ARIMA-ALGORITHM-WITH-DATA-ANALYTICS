<?php include ('db.php'); ?>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
        ['Year', 'Price'],
        <?php
            $query="select * from dataset_backup where DATE_TIME between '2021-01-01' and '2021-12-31'";
            $res=mysqli_query($conn,$query);
            while($data=mysqli_fetch_array($res)){
              $year=$data['DATE_TIME'];
              $sale=$data['PRICE'];
             
           ?>
           ['<?php echo $year;?>',<?php echo $sale;?>],   
           <?php   
            }
           ?> 
        ]);

        var options = {
          title: 'Oil Price Chart', 
          hAxis: {title: 'Year',  titleTextStyle: {color: '#333'}},
          vAxis: {minValue: 0}
		  
        };

        var chart = new google.visualization.AreaChart(document.getElementById('chart_div'));
        chart.draw(data, options);
      }
    </script>
	

    <div id="chart_div" style="width: 100%; height: 500px;"></div></div>

