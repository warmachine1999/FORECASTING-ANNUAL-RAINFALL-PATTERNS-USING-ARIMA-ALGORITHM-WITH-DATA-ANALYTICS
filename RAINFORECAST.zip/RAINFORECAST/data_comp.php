<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rainfall Data</title>
</head>
<body>

<div class="table" style="width:50%;">
<table class="table text-start align-middle table-bordered table-hover mb-0">
        <thead>
            <tr>
                <th scope="col" style="font-size:15px;">Latest Recorded Date</th>
                <th scope="col"style="font-size:15px;">Latest Recorded Rainfall Data</th>
                <th scope="col"style="font-size:15px;">Forecasted Rainfall Data</th>
				<th scope="col"style="font-size:15px;">Percentage Error</th>
                <th scope="col"style="font-size:15px;">Accuracy Level</th>
            </tr>
        </thead>
        <tbody>

<?php
try {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "rainforecast";

    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch latest recorded rainfall data
    $query_latest_recorded = "SELECT rain_date, RAINFALL FROM rainfall_data ORDER BY id DESC LIMIT 1";
    $stmt_latest_recorded = $conn->query($query_latest_recorded);
    $latest_recorded = $stmt_latest_recorded->fetch(PDO::FETCH_ASSOC);

    // Fetch latest forecasted rainfall data
    $query_latest_forecast = "SELECT forecast_date, forecast_data FROM rainfall_forecast ORDER BY id DESC LIMIT 1";
    $stmt_latest_forecast = $conn->query($query_latest_forecast);
    $latest_forecast = $stmt_latest_forecast->fetch(PDO::FETCH_ASSOC);

    // Calculate percentage error and accuracy level
    $actual = $latest_recorded['RAINFALL'];
    $predicted = $latest_forecast['forecast_data'];

    // Check if actual rainfall is zero to avoid division by zero error
    if ($actual != 0) {
        $error = ($predicted - $actual) / $actual * 100;
        $accuracy = 100 - abs($error);
    } else {
        // Set default values if actual rainfall is zero
        $error = 0;
        $accuracy = 0;
    }

    // Display data in table row
    echo "<tr>";
    echo "<td style='font-size:15px;'>" . date('M d, Y', strtotime($latest_recorded['rain_date'])) . "</td>";
    echo "<td style='font-size:15px;'>" . $latest_recorded['RAINFALL'] . "</td>";
    echo "<td style='font-size:15px;'>" . $latest_forecast['forecast_data'] . "</td>";
    echo "<td style='font-size:15px;'> " . number_format(abs($error), 2) . "%</td>";
    echo "<td style='font-size:15px;'> " . number_format($accuracy, 2) . "%</td>";
    echo "</tr>";

} catch (PDOException $e) {
    // Handle exceptions
    echo "Error: " . $e->getMessage();
}
?>


        </tbody>
       
    </table>
    
</div>

</body>
</html>
